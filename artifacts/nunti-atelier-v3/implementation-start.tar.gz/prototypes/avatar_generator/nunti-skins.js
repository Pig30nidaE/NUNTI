'use strict';
(() => {
  // Locked for the offline milestone. Android independently blocks model endpoints.
  const MOCK_SKIN_MODE = true;
  const legacyVersion = 'skin-v2.0';
  const version = 'skin-v2.1';
  const storageKey = 'nunti.skin-v2.records';
  const base = Object.freeze({
    skinId:'default', name:'기본 눈티 A', outfit:'기본 여행복', headStyle:'기본 새싹 후드', earStyle:'둥근 후드',
    eyeStyle:'기본 눈매', accessories:Object.freeze(['기본 여행 가방']), palette:'#6B9B83', pattern:'기본'
  });
  const wardrobe = Object.freeze(Object.fromEntries(Object.entries({
    default:base,
    sea:{skinId:'sea',name:'바닷길 탐험가',outfit:'줄무늬 세일러 재킷 · 모래색 스니커즈',headStyle:'물결 선원 모자와 비스듬한 새싹',earStyle:'조개 귀 장식',eyeStyle:'편안한 타원 눈매',accessories:['조개 파우치'],palette:'#3583A4',pattern:'포말과 물결'},
    city:{skinId:'city',name:'밤도시 모험가',outfit:'반사 띠 오버핏 봄버 · 하이톱',headStyle:'옆으로 넘긴 머리와 새싹',earStyle:'오버이어 헤드폰',eyeStyle:'호기심 어린 눈썹과 눈매',accessories:['크로스백'],palette:'#826CC3',pattern:'도시 불빛'},
    mountain:{skinId:'mountain',name:'산길 트레커',outfit:'바람막이와 하이킹 바지 · 트레일 부츠',headStyle:'니트 모자와 곧게 선 새싹',earStyle:'위로 솟은 귀 장식',eyeStyle:'생기 있는 눈매',accessories:['등산 배낭'],palette:'#5E8460',pattern:'등고선'}
  }).map(([key,value])=>[key,Object.freeze({...value,accessories:Object.freeze(value.accessories)})])));
  const fixtures = Object.freeze({
    default:{name:'기본 눈티',destinationCategory:'unknown',roadType:'unknown',mood:'unset',points:null},
    sea:{name:'파도 해변',destinationCategory:'coast',roadType:'highway',mood:'calm',points:[[.08,.72],[.25,.54],[.46,.63],[.71,.32],[.92,.26]]},
    city:{name:'밤의 도시',destinationCategory:'city',roadType:'urban',mood:'curious',points:[[.08,.8],[.26,.8],[.26,.53],[.57,.53],[.57,.25],[.89,.25]]},
    mountain:{name:'새싹 능선',destinationCategory:'mountain',roadType:'rural',mood:'adventurous',points:[[.08,.82],[.24,.69],[.38,.72],[.51,.44],[.62,.54],[.87,.2]]}
  });
  const own = (obj,key)=>Object.hasOwn(obj,key);
  const knownVersion = value => value===version||value===legacyVersion;
  const path = (id,layer='final',assetVersion=version)=>{
    if(!own(wardrobe,id)||!['final','outfit','head','eyes','accessory'].includes(layer))throw new Error('UNKNOWN_SKIN_ASSET');
    if(!knownVersion(assetVersion))throw new Error('UNKNOWN_SKIN_VERSION');
    const directory=assetVersion===version&&id!=='default'?'/skin-v2/polish/':'/skin-v2/';
    return directory+id+'/'+layer+'.png';
  };
  function resolve({destinationCategory,roadType,mood,routeId}={}) {
    const destination = ['sea','coast','city','mountain'].includes(destinationCategory)?destinationCategory:'unknown';
    const skin = wardrobe[destination==='coast'?'sea':destination] || base;
    const road = ['urban','highway','rural','mixed'].includes(roadType)?roadType:'unknown';
    const selected = ['calm','curious','adventurous','excited'].includes(mood)?mood:'unset';
    return {...skin, version, mood:selected==='excited'?'adventurous':selected, road, routeId:typeof routeId==='string'?routeId:'none',
      animationPreset:{ribbon:road==='urban'?'segmented':road==='rural'?'dotted':'solid',
        sweep: selected==='adventurous' || selected==='excited' ? 'uphill' : selected==='curious' ? 'diagonal' : 'horizontal'}};
  }
  function phaseAt(elapsed) {
    return elapsed>=4000?'FINAL_IDLE':elapsed>=3300?'SKIN_REVEAL':elapsed>=2000?'HEAD_AND_EYES_TRANSFORM':
      elapsed>=1200?'OUTFIT_SWAP':elapsed>=500?'ROUTE_ENERGY':'DEFAULT_IDLE';
  }
  function storage() { return JSON.parse(localStorage.getItem(storageKey)||'{}'); }
  function list() {
    return Object.values(storage()).filter(isSkin).sort((a,b)=>b.savedAt-a.savedAt);
  }
  function isSkin(artifact) {
    const spec=artifact?.design?.skinSpec;
    return knownVersion(spec?.version)&&typeof spec.skinId==='string'&&own(wardrobe,spec.skinId)&&
      /^nunti-skin-[a-f0-9]{32}$/.test(artifact.characterId||'')&&artifact.visual?.path===path(spec.skinId,'final',spec.version);
  }
  async function digest(text) {
    return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text))),b=>b.toString(16).padStart(2,'0')).join('');
  }
  async function createRecord(input, context, finalAvailable) {
    let spec=resolve(context);
    const requested=spec.skinId;
    if(!finalAvailable)spec={...resolve({...context,destinationCategory:'unknown'}),fallback:'FINAL_ASSET_MISSING',requestedSkinId:requested};
    const characterId='nunti-skin-'+(await digest(JSON.stringify([version,input,spec]))).slice(0,32);
    return {characterId,savedAt:Date.now(),destination:input.destination,purpose:input.purpose,route:input.route,
      displayName:spec.name,mediaOrigin:'MOCK_SKIN',visual:{path:path(spec.skinId)},
      design:{skinSpec:spec,staticOnly:true,personality:spec.outfit,motifs:[]},
      voice:{provider:'DEVICE_SPEECH',description:'기기에 설치된 오프라인 음성',pitch:1.08,rate:1}};
  }
  function save(record) {
    if(!isSkin(record))throw new Error('INVALID_SKIN_RECORD');
    const records=storage();
    if(records[record.characterId])return records[record.characterId];
    records[record.characterId]=record;
    localStorage.setItem(storageKey,JSON.stringify(records));
    return record;
  }
  function assertRequest(path,method) {
    if(!MOCK_SKIN_MODE)return;
    const local=typeof path==='string'&&path.startsWith('/')&&!path.startsWith('//')&&!/[\\\r\n]/.test(path);
    // Only the existing local session and route tools may mutate server state.
    if(!local||(method!=='GET'&&!['/session','/v3/route-extractions','/v3/route-plans'].includes(path)))throw new Error('MOCK_SKIN_MODE');
  }
  window.NuntiSkins=Object.freeze({MOCK_SKIN_MODE,version,storageKey,fixtures,resolve,path,phaseAt,isSkin,list,save,createRecord,assertRequest});
})();
