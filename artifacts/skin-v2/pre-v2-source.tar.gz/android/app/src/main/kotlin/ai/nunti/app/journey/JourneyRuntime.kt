package ai.nunti.app.journey

import android.content.Context
import android.util.AtomicFile
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** One Android-owned trip. Server assets are immutable; scores stay on the device. */
object JourneyRuntime {
    @Volatile private var value: String? = null
    @Volatile var isRunning = false
        internal set
    val current: JSONObject? get() = value?.let(::JSONObject)

    internal fun publish(context: Context, snapshot: JSONObject, persist: Boolean) {
        value = snapshot.toString()
        if (persist) write(File(context.filesDir, "journeys/latest.json"), snapshot)
    }

    fun latest(context: Context): JSONObject? {
        current?.let { return it }
        return runCatching {
            JSONObject(File(context.filesDir, "journeys/latest.json").readText()).apply {
                put("canFinish", false)
                if (optString("state") == "ACTIVE") {
                    put("state", "INTERRUPTED")
                    put("line", "앱이 중단되어 여정 기록을 멈췄어요. 마지막 저장 기록입니다.")
                }
            }
        }.getOrNull()
    }

    internal fun write(file: File, data: JSONObject) {
        file.parentFile?.mkdirs()
        val atomic = AtomicFile(file)
        val stream = atomic.startWrite()
        try { stream.write(data.toString().toByteArray()); atomic.finishWrite(stream) }
        catch (error: Exception) { atomic.failWrite(stream); throw error }
    }
}

/** Local authenticated transport; neither bridge callers nor assets choose a host or path. */
internal class JourneyAssets(private val context: Context) {
    private val base = "http://127.0.0.1:8768"
    private val config = JSONObject(File(context.filesDir, "avatar-studio-connection.json").readText())
    private val token = config.getString("token")
    init { require(config.getString("baseUrl") == base && token.length in 32..256) }

    private fun get(path: String, limit: Int): ByteArray {
        val connection = URL(base + path).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 4000; connection.readTimeout = 10000
            connection.instanceFollowRedirects = false
            connection.setRequestProperty("Authorization", "Bearer $token")
            check(connection.responseCode in 200..299) { "자산을 불러오지 못했어요 (${connection.responseCode})" }
            return connection.inputStream.use { stream ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                while (true) {
                    val count = stream.read(buffer)
                    if (count < 0) break
                    check(output.size() + count <= limit) { "자산이 너무 큽니다" }
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            }
        } finally { connection.disconnect() }
    }

    private fun json(path: String) = JSONObject(String(get(path, 2_000_000))).getJSONObject("data")
    private fun asset(record: JSONObject, extension: String): File {
        val sha = record.getString("sha256")
        require(sha.matches(Regex("[0-9a-f]{64}")) && record.getString("path") == "/v3/assets/$sha")
        val file = File(context.filesDir, "journeys/assets/$sha.$extension")
        fun hash(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
        if (file.isFile && hash(file.readBytes()) == sha) return file
        val bytes = get("/v3/assets/$sha", 20_000_000)
        check(hash(bytes) == sha) { "자산 검증에 실패했어요" }
        file.parentFile?.mkdirs()
        val atomic = AtomicFile(file); val output = atomic.startWrite()
        try { output.write(bytes); atomic.finishWrite(output) }
        catch (error: Exception) { atomic.failWrite(output); throw error }
        return file
    }

    fun prepare(characterId: String, source: String): File {
        require(characterId.matches(Regex("nunti-[0-9a-f-]{36}")))
        require(source == "LIVE" || source == "DEMO")
        val artifact = json("/v3/avatars/$characterId")
        check(artifact.getString("characterId") == characterId)
        val image = asset(artifact.getJSONObject("visual"), "png")
        val voices = JSONObject()
        artifact.optJSONObject("voice")?.optJSONObject("audio")?.let {
            voices.put("GREETING", asset(it, "wav").absolutePath)
        }
        for (kind in listOf("NEUTRAL", "WORRY", "RELIEF", "JOY")) {
            // Preparing a journey never starts model inference; the parked UI requests it explicitly.
            runCatching {
                val clip = json("/v3/avatars/$characterId/feedback-voice/$kind")
                check(clip.getString("characterId") == characterId && clip.getString("kind") == kind)
                voices.put(kind, asset(clip.getJSONObject("audio"), "wav").absolutePath)
            }
        }
        val sessionId = java.util.UUID.randomUUID().toString()
        val metadata = JSONObject()
            .put("sessionId", sessionId).put("characterId", characterId)
            .put("displayName", artifact.getString("displayName"))
            .put("destination", artifact.getJSONObject("destination").getString("name"))
            .put("purpose", artifact.optString("purpose"))
            .put("routePlanId", artifact.optJSONObject("route")?.optString("apiPlanId")?.ifBlank { null })
            .put("staticOnly", artifact.optJSONObject("design")?.optBoolean("staticOnly", false) == true ||
                artifact.optString("mediaOrigin") == "LOCAL_LAYERS")
            .put("imageFile", image.absolutePath).put("voices", voices).put("source", source)
            .put("startedAtEpochMs", System.currentTimeMillis())
        val file = File(context.filesDir, "journeys/$sessionId-input.json")
        JourneyRuntime.write(file, metadata)
        return file
    }
}
